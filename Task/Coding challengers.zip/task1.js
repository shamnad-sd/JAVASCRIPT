massMark = 78;
heightMark = 1.69;

massJohn = 92;
heightJohn =1.95;

BMIMark = massMark / (heightMark * heightMark);
BMIJohn = massJohn / (heightJohn * heightJohn);

console.log(BMIMark);
console.log(BMIJohn);
