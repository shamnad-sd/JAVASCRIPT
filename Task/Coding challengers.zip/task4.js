// bill = 275;
// console.log(` The bill was ${bill}`)
// tip = bill/100*15;
// console.log(`The tip was ${tip}`)
// total = bill+tip;
// console.log(`the total of ${total}`)

bill = 275;
amount = bill < 300 ? tip = bill/100*15 : tip = bill/100*20

console.log(`The bill was ${bill}`)
console.log(`The tip was ${amount}`)
console.log(`the total of ${bill+tip}`)
